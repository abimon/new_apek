<nav class="navbar navbar-expand-lg navbar-light bg-white shadow fixed-top">
  <div class="container">
    <a class="d-flex align-items-center gap-2 order-lg-1" href="/storage/index.html">
      <img src="/storage/assets/images/brand/logo/logo-icon.svg" alt="" />
      <span class="fw-bold fs-4 site-logo-text">Dasher</span>
    </a>
    <div class="d-flex align-items-center gap-2 order-lg-3">
      <div class="dropdown">
        <button class="btn btn-ghost btn-icon rounded-circle d-flex align-items-center" type="button" aria-expanded="false" data-bs-toggle="dropdown" aria-label="Toggle theme (auto)">
          <i class="ti theme-icon-active lh-1 fs-5"><i class="ti theme-icon ti-sun"></i></i>
          <span class="visually-hidden bs-theme-text">Toggle theme</span>
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow">
          <li>
            <button type="button" class="dropdown-item d-flex align-items-center active" data-bs-theme-value="light" aria-pressed="true">
              <i class="ti theme-icon ti ti-sun"></i>
              <span class="ms-2">Light</span>
            </button>
          </li>
          <li>
            <button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="dark" aria-pressed="false">
              <i class="ti theme-icon ti-moon-stars"></i>
              <span class="ms-2">Dark</span>
            </button>
          </li>
          <li>
            <button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="auto" aria-pressed="false">
              <i class="ti theme-icon ti-circle-half-2"></i>
              <span class="ms-2">Auto</span>
            </button>
          </li>
        </ul>
      </div>
      <a href="#" class="btn btn-primary">Buy Now</a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
    <div class="collapse navbar-collapse order-lg-2" id="navbarSupportedContent">
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/storage/index.html">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/storage/components/accordions.html">Components</a>
        </li>

        <li class="nav-item">
          <a href="/storage/docs/index.html" class="nav-link">Docs</a>
        </li>
      </ul>
    </div>
  </div>
</nav>