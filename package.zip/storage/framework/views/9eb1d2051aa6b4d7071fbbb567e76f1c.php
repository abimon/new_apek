<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("partials.head.head-meta", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <title>Dashboard</title>
    <link rel="stylesheet" href="/storage/node_modules/swiper/swiper-bundle.min.css" />
    <?php echo $__env->make("partials.head.head-links", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <style>
        :root {
            color-scheme: dark;
            background: #0F172A;
            color: #F8FAFC;
        }

        body {
            background: radial-gradient(circle at top, rgba(56, 189, 248, 0.16), transparent 35%),
                linear-gradient(180deg, #020617 0%, #0F172A 100%);
            min-height: 100vh;
            margin: 0;
            line-height: 1.6;
            /* font-family: 'Share Tech Mono', monospace; */
            /* font-family: 'JetBrains Mono', monospace; */
        }


        .glass-panel {
            background: rgba(15, 23, 42, 0.76);
            border: 1px solid rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(16px);
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.24);
        }

        a {
            text-decoration: none;
        }
    </style>
</head>

<body>


    <!-- Vertical Sidebar -->
    <div>
        <?php echo $__env->make("partials.sidebar-collapse", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make("partials.topbar-second", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Main Content -->
        <div id="content" class="position-relative h-100">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <?php echo $__env->make("partials.scripts", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- jsvectormap -->
</body>

</html><?php /**PATH D:\Personal\Apek\resources\views/components/dash.blade.php ENDPATH**/ ?>