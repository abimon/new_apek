<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Skills | Developer Portfolio <?php $__env->endSlot(); ?>

    <section style="padding: 2.5rem 0 1.5rem; display: grid; gap: 1.5rem;">
        <div class="section-title">Skills</div>
        <p class="section-subtitle">A modern, professional skill map for mobile, backend, frontend, database, IoT, and programming languages.</p>
    </section>

    <section style="display: grid; gap: 1rem;">
        <div class="glass-panel" style="padding: 1.5rem; display: grid; gap: 1rem;">
            <?php $__currentLoopData = $skills->groupBy('category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <h3 style="margin: 0 0 0.75rem; color: #fff;"><?php echo e($category); ?></h3>
                    <div style="display: grid; gap: 0.85rem;">
                        <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div style="display: grid; gap: 0.35rem;">
                                <div style="display: flex; justify-content: space-between; font-weight: 700; color: #f8fafc;"><span><?php echo e($skill->name); ?></span><span><?php echo e($skill->proficiency); ?>%</span></div>
                                <div style="background: rgba(255,255,255,0.08); border-radius: 9999px; overflow: hidden; height: 0.75rem;">
                                    <div style="width: <?php echo e($skill->proficiency); ?>%; background: linear-gradient(90deg, #2563EB, #14B8A6); height: 100%;"></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Personal\Apek\resources\views/skills.blade.php ENDPATH**/ ?>