<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Login | Developer Portfolio <?php $__env->endSlot(); ?>
    <section style="padding: 4rem 0; display: grid; gap: 1.5rem; max-width: 520px; margin: 0 auto;">
        <div class="glass-panel" style="padding: 2rem;">
            <h1 style="margin-top: 0; color: #fff;">Admin Login</h1>
            <form method="POST" action="<?php echo e(route('login')); ?>" style="display: grid; gap: 1rem;">
                <?php echo csrf_field(); ?>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required style="width: 100%; padding: 1rem; border-radius: 1rem; border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05); color: #f8fafc;" />
                <input type="password" name="password" placeholder="Password" required style="width: 100%; padding: 1rem; border-radius: 1rem; border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05); color: #f8fafc;" />
                <button type="submit" class="button-primary">Login</button>
            </form>
            <p style="color: #94a3b8; margin-top: 1rem;">No account? <a href="<?php echo e(route('register')); ?>" style="color: #38bdf8;">Register here</a>.</p>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Personal\Apek\resources\views/auth/login.blade.php ENDPATH**/ ?>