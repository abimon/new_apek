<article class="glass-panel" style="padding: 1.5rem;">
    <h3 style="margin-top: 0; color: #fff;"><?php echo e($project->title); ?></h3>
    <p style="color: #cbd5e1;"><?php echo e(\Illuminate\Support\Str::limit($project->description, 140)); ?></p>
    <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin: 1rem 0;">
        <?php $__currentLoopData = $project->technologies ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge bg-secondary"><?php echo e($technology); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 0.75rem;">
        <a href="<?php echo e(route('project.show', $project->slug)); ?>" class="btn btn-secondary w-75">View Details</a>
        <?php if($project->live_url): ?>
            <a href="<?php echo e($project->live_url); ?>" class="button-secondary">Live Demo</a>
        <?php endif; ?>
    </div>
</article>
<?php /**PATH D:\Personal\Apek\resources\views/partials/project-card.blade.php ENDPATH**/ ?>