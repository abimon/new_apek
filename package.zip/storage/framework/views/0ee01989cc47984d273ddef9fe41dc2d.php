<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Contact | Developer Portfolio <?php $__env->endSlot(); ?>

    <section style="padding: 2.5rem 0 1.5rem; display: grid; gap: 1.5rem;">
        <div class="section-title">Contact</div>
        <p class="section-subtitle">Get in touch for project inquiries, collaboration, or hiring.</p>
    </section>

    <section class="glass-panel" style="padding: 1.75rem; display: grid; gap: 1.25rem;">
        <?php if(session('success')): ?>
            <div style="background: #10b981; color: white; padding: 1rem; border-radius: 1rem;"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div style="background: rgba(248, 113, 113, 0.18); color: #fee2e2; padding: 1rem; border-radius: 1rem;">
                <ul style="margin: 0; padding-left: 1.25rem;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('contact.send')); ?>" method="POST" style="display: grid; gap: 1rem;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="website" value="" />
            <div style="display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));">
                <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Name" style="padding: 1rem; border-radius: 0.95rem; border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05); color: #f8fafc;" required />
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" style="padding: 1rem; border-radius: 0.95rem; border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05); color: #f8fafc;" required />
            </div>
            <div style="display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));">
                <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Phone" style="padding: 1rem; border-radius: 0.95rem; border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05); color: #f8fafc;" />
                <input type="text" name="subject" value="<?php echo e(old('subject')); ?>" placeholder="Subject" style="padding: 1rem; border-radius: 0.95rem; border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05); color: #f8fafc;" required />
            </div>
            <textarea name="message" placeholder="Message" rows="6" style="padding: 1rem; border-radius: 0.95rem; border: 1px solid rgba(255,255,255,0.12); background: rgba(255,255,255,0.05); color: #f8fafc;" required><?php echo e(old('message')); ?></textarea>
            <button type="submit" class="button-primary">Send Message</button>
        </form>

        <div style="display: grid; gap: 0.75rem; padding-top: 1rem; border-top: 1px solid rgba(255,255,255,0.08);">
            <p style="margin: 0; color: #cbd5e1;">GitHub: <a href="https://github.com" style="color: #38bdf8;">https://github.com</a></p>
            <p style="margin: 0; color: #cbd5e1;">LinkedIn: <a href="https://linkedin.com" style="color: #38bdf8;">https://linkedin.com/</a></p>
            <p style="margin: 0; color: #cbd5e1;">Email: <a href="mailto:developer@example.com" style="color: #38bdf8;">developer@example.com</a></p>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Personal\Apek\resources\views/contact.blade.php ENDPATH**/ ?>